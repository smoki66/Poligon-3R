// Klasa za liste geometrijskih figura (Lista).

#ifndef _lista_h_
#define _lista_h_

#include "zbirka.h"

class Lista: public Zbirka {
  friend class LIter;                         // Iterator za liste.
  struct Elem {                               // Element liste:
    Figura* fig;                              //   - figura u elementu
    Elem* sled;                               //   - sledeci element
    Elem (Figura* f, Elem* s=0)               //   - konstruktor elementa
      { fig = f; sled = s; }
  };
  Elem *prvi, *posl;                          // Prvi i poslednji element.
  int  vel;                                   // Broj elemenata liste.
  void kopiraj (const Lista& lst);            // Kopiranje u listu.
  void brisi ();                              // Unistavanje liste.
public:
  Lista () { prvi = posl = 0; vel = 0; }      // Konstruktor prazne liste.
  Lista (const Lista& lst) { kopiraj (lst); } // Konstruktor kopije.
  ~Lista () { brisi (); }                     // Destruktor.
  Lista& operator= (const Lista& lst) {       // Dodela vrednosti.
    if (this != &lst) { brisi (); kopiraj (lst); }
    return *this;
  }
  int operator+ () const { return vel; }      // Broj elemenata liste.
  Lista& operator+= (Figura* fig) {           // Dodavanje figure.
    posl = (!prvi ? prvi : posl->sled) = new Elem (fig);
    vel++;
    return *this;
  }
  Figura*& operator[] (int ind) ;             // Dohvatanje figure.
  const Figura* operator[] (int ind) const
    { return const_cast<Lista&>(*this)[ind]; }
  Lista& operator~ ()                         // Praznjenje liste.
    { brisi (); return *this;}
  Lista* kopija () const                      // Stvaranje kopije liste.
    { return new Lista (*this); }
  Iter* iter () ;                             // Stvaranje iteratora.
  const Iter* iter () const ;
};

#endif
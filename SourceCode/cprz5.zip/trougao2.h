// Definicija klase obojenih trouglova (Trougao).

#ifndef _trougao2_h_
#define _trougao2_h_

#include "figura2.h"
#include <cmath>
using namespace std;

namespace Figure {
  class Trougao: public Figura {
    Tacka A, B, C;                           // Temena.
  public:                                    // Konstruktor.
    Trougao (Tacka P, Tacka Q, Tacka R, Boja b=Boja())
      : Figura (b), A(P), B(Q), C(R) {}
    Trougao* kopija () const { return new Trougao (*this); } // Kopija.
  private:
    double P () const {
      double a = B - C, b = C - A, c = A - B, s = (a + b + c) / 2;
      return sqrt (s * (s-a) * (s-b) * (s-c));
    }
    bool pripada (const Tacka& T) const {    // Da li tacka pripada?
      return fabs (Trougao(T,A,B).P() + Trougao(T,B,C).P() +
                   Trougao(T,C,A).P() - P()                  ) < 1E-8;
    }
    virtual void pisi (ostream& it) const    // Pisanje.
      { it << " A=" << A << " B=" << B << " C=" << C; }
  } ; // class Trougao
} // namespace Figure

#endif

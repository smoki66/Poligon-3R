// Definicija klase vremenskih intervala (Vreme).

#include <iostream>
using namespace std;

class Vreme {
  long t;                                        // Vreme u sekundama.
public:
  Vreme (int h, int m, int s)                    // Sastavljanje vremena.
    { t = ((h * 60L + m) * 60 + s); }
  Vreme (long s=0) { t = s; }                       // Sekunde u vreme.
  friend int  sat (Vreme v) { return v.t / 3600; }  // Sati u vremenu.
  friend int  min (Vreme v) { return (v.t/60)%60; } // Minuti u vremenu.
  friend int  sek (Vreme v) { return v.t % 60; }    // Sekunde u vremenu.
  friend long Sek (Vreme v) { return v.t; }         // Vreme u sekunde.
  Vreme  operator+  () const { return  *this; }                // +t
  Vreme  operator-  () const { return Vreme (-t); }            // -t
  Vreme& operator++ ()    { ++t; return *this; }               // ++t
  Vreme  operator++ (int) { Vreme w (*this); t++; return w; }  // t++
  Vreme& operator-- ()    { --t; return *this; }               // --t
  Vreme  operator-- (int) { Vreme w (*this); t--; return w; }  // t--
  friend Vreme operator+ (const Vreme& v, const Vreme& w)      // v +  w
    { return Vreme (v.t + w.t); }
  friend Vreme operator- (const Vreme& v, const Vreme& w)      // v -  w
    { return Vreme (v.t - w.t); }
  friend Vreme operator* (const Vreme& v, int k)               // v *  k
    { return Vreme (v.t * k); }
  friend Vreme operator/ (const Vreme& v, int k)               // v /  k
    { return Vreme (v.t / k); }
  typedef const Vreme CV;
  Vreme& operator+= (CV& v) { t += v.t; return *this; }        // t += v
  Vreme& operator-= (CV& v) { t -= v.t; return *this; }        // t -= v
  Vreme& operator*= (int k) { t *= k;   return *this; }        // t *= k
  Vreme& operator/= (int k) { t /= k;   return *this; }        // t /= k
  friend int operator< (CV& v, CV& w) { return v.t< w.t; }     // v <  w
  friend int operator<=(CV& v, CV& w) { return v.t<=w.t; }     // v <= w
  friend int operator> (CV& v, CV& w) { return v.t> w.t; }     // v >  w
  friend int operator>=(CV& v, CV& w) { return v.t>=w.t; }     // v >= w
  friend int operator==(CV& v, CV& w) { return v.t==w.t; }     // v == w
  friend int operator!=(CV& v, CV& w) { return v.t!=w.t; }     // v != w
  friend ostream& operator<<(ostream& it, CV& v) {         // Ispisivanje.
    Vreme w (v); if (w.t < 0) { it << '-'; w = - w; }
    return it << sat (w) << ':' << min (w) << ':' << sek (w);
  }
  friend istream& operator>>(istream& ut, Vreme& v) {      // Citanje.
    int h, m, s; char z; ut >> h >> z >> m >> z >> s;
    v = Vreme (h, m, s); return ut;
  }
};

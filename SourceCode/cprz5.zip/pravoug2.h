// Definicija klase obojenih pravougaonika (Pravoug).

#ifndef _pravoug2_h_
#define _pravoug2_h_

#include "figura2.h"

namespace Figure {
  class Pravoug: public Figura {
    Tacka A, C;            // Temena dole-levo i gore-desno.
  public:                                  // Konstruktor.
    Pravoug (Tacka P, Tacka Q, Boja b=Boja())
      : Figura (b),
        A(P.uzmi_x()<Q.uzmi_x()?P.uzmi_x():Q.uzmi_x(),
          P.uzmi_y()<Q.uzmi_y()?P.uzmi_y():Q.uzmi_y()),
        C(P.uzmi_x()<Q.uzmi_x()?Q.uzmi_x():P.uzmi_x(),
          P.uzmi_y()<Q.uzmi_y()?Q.uzmi_y():P.uzmi_y()) {}
    Pravoug* kopija () const { return new Pravoug (*this); } // Kopija.
  private:
    bool pripada (const Tacka& T) const {  // Da li tacka pripada?
      return A.uzmi_x()<=T.uzmi_x() && T.uzmi_x()<=C.uzmi_x() &&
             A.uzmi_y()<=T.uzmi_y() && T.uzmi_y()<=C.uzmi_y();
    }
    virtual void pisi (ostream& it) const // Pisanje.
      { it << " A=" << A << " C=" << C; }
  } ; // class Pravoug
} // namespace Figure

#endif

// Definicija klase krugova u ravni (Krug).

#include "tacka1.h"
#include <cstdlib>
#include <cmath>
#include <iostream>
using namespace std;

class Krug {
  Tacka c; double r;          // Centar i poluprecnik kruga.
  struct Elem {               // Element zajednicke liste svih krugova.
    Krug* krug;               //   - pokazivac na krug,
    Elem* sled;               //   - pokazivac na sledeci element liste,
    Elem (Krug* k, Elem* s=0);//   - stvaranje elementa liste.
  };
  static Elem* prvi;          // Pocetak zajednicke liste.
  Krug () { r = -1; }         // Stvaranje "praznog" kruga:
                              //   - SAMO za interne potrebe!
  Krug (const Krug&) {}      // Konstruktor kopije:
                              //   - NE SME da se pravi kopija!
public:
  Krug (double rr, double x, double y);      // Stvaranje kruga;
  ~Krug ();                                  // Unistavanje kruga.
  static bool moze (double r, double x, double y);  // Moze li stati?
  friend double rastojanje (const Krug& k1, const Krug& k2);
                                             // Rastojanje dva kruga.
  bool postavi (double  x, double  y);       // Postavljanje kruga.
  bool pomeri  (double dx, double dy);       // Pomeranje kruga.
  void pisi () const;                        // Pisanje kruga.
  static void pisi_sve ();                   // Pisanje svih krugova.
};

// Definicije ugradjenih funkcija.

inline double rastojanje (const Krug& k1, const Krug& k2)
                                             // Rastojanje dva kruga.
  { return k1.c.rastojanje (k2.c) - k1.r - k2.r; }

inline void Krug::pisi () const              // Pisanje kruga.
  { cout << "K[" << r << ','; c.pisi(); cout << ']'; }

inline Krug::Elem::Elem (Krug* k, Elem* s)   // Stvaranje elementa liste.
  { krug = k; sled = s; }

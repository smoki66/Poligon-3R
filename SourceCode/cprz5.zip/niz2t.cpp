// Ispitivanje klasa Niz i NIter.

#include "niz2.h"
#include "niter.h"
#include "krug2.h"
#include "kvadrat.h"
#include "trougao1.h"
#include <iostream>
using namespace std;

int main () {
  // Stvaranje niza.
  Niz niz; niz += new Krug    (3, Tacka(1,2));
           niz += new Trougao (3, 4, 5, Tacka(7,8));
           niz += new Kvadrat (2, Tacka(9,8));
  for (int n=+niz, i=0; i<n; niz+=*niz[i++]);
  cout << "Pocetni niz:\n" << niz << endl;

  // Uredjivanje niza prema povrsinama figura.
  for (int i=0; i<+niz-1; i++)
    for (int j=i+1; j<+niz; j++)
      if (niz[j]->P() < niz[i]->P())
        { Figura* f = niz[i]; niz[i] =  niz[j]; niz[j] = f; }
  cout << "Uredjeni niz:\n";
  for (const NIter i(&niz); i.ima(); ++i)
    cout << "  " << *i << endl;

  // Vadjenje svakog drugog elementa niza.
  cout << "\nIzvadjene figure:\n";
  for (NIter i(&niz); i.ima(); ++i)
   { Figura* f = ~i; cout << "  " << *f << endl;  delete f; }
  cout <<"\nPrepolovljeni niz:\n" << niz << endl;
};
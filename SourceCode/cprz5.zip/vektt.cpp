// Program za ispitivanje klase Vekt.

#include "vekt.h"
#include <iostream>
#include <new>
using namespace std;

int main () {
  while (true) {
    try {
      int min, max;
      cout << "Opseg indeksa prvog  vektora: "; cin >> min >> max;
  if (min==0 && max==0) break;
      Vekt v1 (min, max); cout << "Elementi prvog  vektora:      ";
      for (int i=min; i<=max; i++) cin >> v1[i];
      cout << "Opseg indeksa drugog vektora: "; cin >> min >> max;
      Vekt v2 (min, max); cout << "Elementi drugog vektora:      ";
      for (int i=min; i<=max; i++) cin >> v2[i];
      cout << "Skalarni proizvod = " << v1 * v2 << "\n\n";
    } catch (Vekt::Greska g) {
      char* poruke[] = { "Neispravan opseg indeksa",
                         "Vektor je prazan",
                         "Indeks je izvan opsega",
                         "Neusaglasene duzine vektora"
                       } ;
      cout << "\n*** " << poruke[g] << "!\a\n\n";
    } catch (bad_alloc) {
      cout << "\n*** Dodela memorije nije uspela!\a\n\n";
    }
  }
}

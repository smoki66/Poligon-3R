// Preklapanje operatora ->.

#include <iostream>
using namespace std;

struct Obj { double x, y; };  // Korisceni objekat.

class PokObj {      // Klasa "pametnih" pokazivaca.
  Obj* p;           // Pokazivac na pridruzeni objekat.
  int n;            // Broj pristupa pridruzenom objektu.
public:
  PokObj (Obj* obj)  { n = 0; p = obj; } // Inicijalizacija.
  Obj* operator-> () { n++; return  p; } // Pristup clanu.
  Obj& operator*  () { n++; return *p; } // Pristup objektu.
  int operator+ () const { return n; }   // Broj pristupa.
} ;

int main () {
  Obj a;
  PokObj pa = &a;         // "Pametan" pokazivac.
  pa->x = pa->y = 0;
  cout << +pa << endl;    // Pise se: 2
  Obj b = *pa;
  cout << +pa << endl;    // Pise se: 3
  Obj* pb = &b;           // "Obican" pokazivac.
  pb->x = pb->y = 5;
  *pa = *pb;
  cout << +pa << endl;    // Pise se: 4
}
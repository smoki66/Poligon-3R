// Definicija klase za funkciju sinus (Sin).

#ifndef _sin2_h_
#define _sin2_h_

#include "fct.h"
#include <cmath>
using namespace std;

namespace Funkcije {
  class Sin: public Fct {
  public:
    double operator() (double x) const { return sin (x); }  // Funkcija.
    double I (double x) const { return - cos (x); }         // Integral.
  } ; // class Sin
} // namespace Funkcije

#endif

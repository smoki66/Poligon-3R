// Genericka klasa za opadajuce uredjivanje podataka.

template <typename T>
  class Opada {
  public:
    static bool ispred (const T& a, const T& b) { return b < a; }
  } ;


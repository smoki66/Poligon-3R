// Program za ispitivanje genericke klase za stekove (Stek<>).

#include "stek2.h"
#include <iostream>
using namespace std;

const int CVEL=10, DVEL=3;

void main () {
  int i; double d;
  Stek<int,CVEL>    clb_stek;
  Stek<double,DVEL> dbl_stek;

  cout << "\nPunjenje   celobrojnog steka:";
  while (! clb_stek.pun())
    { cin >> i; clb_stek.stavi (i); cout << ' ' << i; }
  cout << "\nPraznjenje celobrojnog steka:";
  while (! clb_stek.prazan())
    {           clb_stek.uzmi (i);  cout << ' ' << i; }

  cout << "\nPunjenje   realnog steka:";
  while (! dbl_stek.pun())
    { cin >> d; dbl_stek.stavi (d); cout << ' ' << d; }
  cout << "\nPraznjenje realnog steka:";
  while (! dbl_stek.prazan())
    {           dbl_stek.uzmi (d);  cout << ' ' << d; }
  cout << endl;
}

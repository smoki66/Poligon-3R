// Definicija klase tacaka (Tacka).

#include <iostream>
using namespace std;

class Tacka {
  double x, y;                                              // Koordinate.
public:
  friend istream& operator>> (istream& ut, Tacka& tt)       // Citanje.
    { return ut >> tt.x >> tt.y; }
  friend ostream& operator<< (ostream& it, const Tacka& tt) // Pisanje.
    { return it << "T(" << tt.x << ',' << tt.y << ')'; }
  friend int operator<(const Tacka& t1, const Tacka& t2)    // Uporedjivanje.
    { return t1.x*t1.x + t1.y*t1.y < t2.x*t2.x + t2.y*t2.y; }
} ;

// Definicija klase iteratora za nizove (NIter).

#ifndef _niter_h_
#define _niter_h_

#include "iter.h"
#include "niz2.h"

class NIter: public Iter {
  Niz* niz;                                  // Pokazivac na niz.
  mutable int tek;                           // Indeks tekuceg elementa.
public:
  NIter (const Niz* n)                       // Stvaranje iteratora.
    { niz = const_cast<Niz*>(n); tek = 0;}
  bool ima () const                          // Ima li jo� elemenata?
    { return tek >= 0 && tek < niz->vel; }
  NIter &poc ()                              // Pomeranje na pocetak.
    { tek = 0; return *this; }
  NIter& operator++ () {                     // Pomeranje korak napred.
    if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
    tek++;
    return *this;
  }
  Figura* operator-> () {                    // Pokazivac na figuru.
    if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
    return niz->niz[tek];
  }
  NIter& operator+= (Figura* fig);           // Umetanje figure.
  NIter& operator-= (Figura*& fig);          // Vadenje figure.

  // Varijante ranijih operacija za nepromenljive nizove.
  const NIter& poc () const                  // Pomeranje na pocetak.
    { return const_cast<NIter*>(this)->poc(); }
  const NIter& operator++ () const           // Pomeranje korak napred.
    { return ++ const_cast<NIter&>(*this); }
  const Figura* operator-> () const          // Pokazivac na figuru.
    { return (const_cast<NIter*>(this))->operator->(); }
};

#endif
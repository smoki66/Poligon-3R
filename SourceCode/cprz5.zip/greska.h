// Definicija klase za greske (Greska).

#ifndef _greska_h_
#define _greska_h_

#include <iostream>
#include <cstring>
using namespace std;

namespace Usluge {
  class Greska {
    char* poruka;                                 // Tekst poruke o gresci.
    void kopiraj (const char* p) {                // Kopiranje u objekat.
      if (p) {
        poruka = new char [strlen(p)+1];
        strcpy (poruka, p);
      } else poruka = 0;
    }
    void brisi () { delete poruka; poruka = 0; }  // Unistavanje objekta.
  public:                                         // Konstruktori:
    Greska () { poruka = 0; }                     //   podrazumevani,
    Greska (const char* por) { kopiraj (por); }   //   konverzije,
    Greska (const Greska& g) {kopiraj(g.poruka);} //   kopije.
    virtual ~Greska () { brisi (); }              // Destruktor.
    Greska& operator= (const Greska& g) {         // Dodela vrednost.
      if (this != &g) { brisi (); kopiraj (g.poruka); }
      return *this;
    }
  protected:
    virtual void pisi (ostream& it) const {     // Pisanje poruke o gresci.
      it << "\n*** " << (poruka ? poruka : "Greska") << " ***\n\a";
    }
    friend ostream& operator<< (ostream& it, const Greska& g)
      { g.pisi (it); return it; }
    bool ima_poruke() const {return poruka!=0;} // Ima li poruke u objektu?
  } ; // class Greska
} // namespace Usluge

#endif

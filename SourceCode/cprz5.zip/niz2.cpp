// Definicije metoda uz klasu Niz.

#include "niz2.h"
#include "niter.h"

void Niz::kopiraj (const Niz& n) {           // Kopiranje u niz.
  niz = new Figura* [kap = n.kap];
  vel = n.vel;
  for (int i=0; i<vel; i++) niz[i] = n.niz[i]->kopija();
}

Niz& Niz::operator+= (Figura* fig) {         // Dodavanje figure.
  if (vel == kap) {
     Figura** pom = new Figura* [kap += (kap<100) ? 10 : kap/10];
     for (int i=0; i<vel; i++) pom[i] = niz[i];
     delete [] niz;  niz = pom;
  }
  niz[vel++] = fig;
  return *this;
}

Niz& Niz::operator~ () {                     // Praznjenje niza.
  for (int i=0; i<vel; delete niz[i++]);
  vel = 0;
  return *this;
}

Iter* Niz::iter ()                           // Stvaranje iteratora.
  { return new NIter (this); }
const Iter* Niz::iter () const
  { return new NIter (this); }

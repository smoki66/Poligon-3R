// Primer koriscenja klase Tacka.

#include <iostream>
using namespace std;
#include "tacka1.h"

int main () {
  int n; cout << "\nBroj tacaka? "; cin >> n;
  Tacka* niz = new Tacka [n];
  cout << "Niz tacaka? "; for (int i=0; i<n; i++) niz[i].citaj ();
  double x, y; cout << "\nReferentna tacka? "; cin >> x >> y;
  Tacka t; t.postavi (x, y);
  cout << "Koordinate: (" << t.aps () << ',' << t.ord () << ")\n";
  cout << "Poteg i nagib: " << t.poteg () << ", " << t.nagib () << endl;
  Tacka w = t.najbliza (niz, n);
  cout << "\nNajbliza tacka: "; w.pisi (); cout << endl;
  cout << "Udaljenost od referentne tacke: " << t.rastojanje (w) << endl;
  delete [] niz;
}

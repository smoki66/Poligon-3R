// Definicije metoda i zajednickih polja uz klasu RFile.

#include "rfile.h"

const char * RFile::Greska::por[] = { "", // PORUKE O GRESKAMA:
         "Neispravna duzina zapisa",      //   DUZ
         "Neispravan redni broj zapisa",  //   BRO
         "Datoteka nije ceo broj zapisa", //   VEL
         "Datoteka nije otvorena",        //   ZAT
         "Nije uspelo otvaranje",         //   OTV
         "Nije uspelo pozicioniranje",    //   POZ
         "Nije uspelo upisivanje",        //   PIS
         "Nije uspelo citanje",           //   CIT
         "Zapis ne postoji"               //   ZAP
       } ;

ostream& operator<< (ostream& it, const RFile::Greska& g)
  { return it << "*** " << RFile::Greska::por[g.gre] << "! ***\n\a"; }

void RFile::otvori (const char* ime, long duz) { // OTVARANJE DATOTEKE.
  if (duz < 0)     throw Greska (Greska::DUZ);
  if (bro_zap >= 0) close ();           // Datot. otvorena  zatvori.
  if (duz) {                            // Stvaranje nove datoteke.
    fstream::open (ime, ios::in) ;
    if (is_open ())   throw Greska (Greska::OTV);
    fstream::open (ime, ios::in | ios::out | ios::binary) ;
    if (! is_open ()) throw Greska (Greska::OTV);
    if (! fstream::write ((char*)&duz, sizeof (long)) ||
        ! flush())    throw Greska (Greska::PIS);
    duz_zap = duz;
    bro_zap = 0;
  } else {                              // Otvaranje stare datoteke.
    fstream::open (ime, ios::in);
    if (! is_open ())           throw Greska (Greska::OTV);
    fstream::close ();
    fstream::open (ime, ios::in | ios::out | ios::binary);
    if (! is_open ())           throw Greska (Greska::OTV);
    if (! fstream::read ((char*)&duz_zap, sizeof (long)))
                                throw Greska (Greska::CIT);
    if (! seekg (0l, ios::end)) throw Greska (Greska::POZ);
    long k = tellg () - (long)sizeof (long);
    if (k % duz_zap)            throw Greska (Greska::VEL);
    bro_zap = k / duz_zap;
  }
  tek_zap = 0;
  tek_poz = sizeof (long);
}

RFile& RFile::close () {                          // ZATVARANJE DATOTEKE.
  fstream::close ();
  bro_zap = -1;
  return *this;
}

RFile& RFile::write (const void* niz, long zap) { // PISANJE ZAPISA.
  if (bro_zap == -1) throw Greska (Greska::ZAT);
  if (zap < 0)       throw Greska (Greska::BRO);
  if (zap) {                            // Direktan pristup.
    tek_poz = (zap - 1) * duz_zap + sizeof (long);
    tek_zap = zap;
  } else {                              // Sekvencijalni pristup.
    tek_poz += duz_zap;
    tek_zap++;
  }
  if (tek_zap > bro_zap) bro_zap = tek_zap;
  if (! seekp (tek_poz)) throw Greska (Greska::POZ);
  if (! fstream::write ((char*)niz, duz_zap) ||
      ! flush ())        throw Greska (Greska::PIS);
  return *this;
}

RFile& RFile::read (void* niz, long zap) {        // CITANJE ZAPISA.
  if (bro_zap == -1) throw Greska (Greska::ZAT);
  if (zap < 0)       throw Greska (Greska::BRO);
  if (zap) {                            // Direktan pristup.
    tek_poz = (zap - 1) * duz_zap + sizeof (long);
    tek_zap = zap;
  } else {                              // Sekvencijalni pristup.
    tek_poz += duz_zap;
    tek_zap++;
  }
  if (zap > bro_zap)                         throw Greska (Greska::ZAP);
  if (! seekg (tek_poz))                     throw Greska (Greska::POZ);
  if (! fstream::read ((char*)niz, duz_zap)) throw Greska (Greska::CIT);
  return *this;
}

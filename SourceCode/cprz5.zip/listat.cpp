// Ispitivanje klasa Lista i LIter.

#include "lista.h"
#include "liter.h"
#include "krug2.h"
#include "kvadrat.h"
#include "trougao.h"
#include <iostream>
using namespace std;

int main () {
  // Stvaranje liste.
  Lista lst; lst += new Krug    (3, Tacka(1,2));
             lst += new Trougao (3, 4, 5, Tacka(7,8));
             lst += new Kvadrat (2, Tacka(9,8));
  for (int n=+lst, i=0; i<n; lst+=*lst[i++]);
  cout << "Pocetna lista:\n" << lst << endl;

  // Uredjivanje liste prema povrsinama figura.
  for (int i=0; i<+lst-1; i++)
    for (int j=i+1; j<+lst; j++)
      if (lst[j]->P() < lst[i]->P())
        { Figura* f = lst[i]; lst[i] =  lst[j]; lst[j] = f; }
  cout << "Uredjena lista:\n";
  for (const LIter i(&lst); i.ima(); ++i)
    cout << "  " << *i << endl;

  // Vadjenje svakog drugog elementa liste.
  cout << "\nIzvdadjene figure:\n";
  for (LIter i(&lst); i.ima(); ++i)
   { Figura* f = ~i; cout << "  " << *f << endl;  delete f; }
  cout <<"\nPrepolovljena lista:\n" << lst << endl;
};

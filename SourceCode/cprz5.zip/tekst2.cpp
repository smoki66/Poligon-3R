// Inicijalizacija i dodela vrednosti.

#include <cstring>
using namespace std;

class Tekst {
  char* txt;                             // Pokazivac na sam tekst.
public:

  Tekst (const char* niz) {              // Konverzija iz char* u Tkest.
    txt = new char [strlen(niz)+1];
    strcpy (txt, niz);
  }

  Tekst (const Tekst& tks) {             // Inicijalizacija Tkest-om.
    txt = new char [strlen(tks.txt)+1];
    strcpy (txt, tks.txt);
  }

  Tekst& operator= (const Tekst& tks) {  // Dodela vrednosti.
    if (this != &tks) {
      delete [] txt;
      txt = new char [strlen(tks.txt)+1];
      strcpy (txt, tks.txt);
    }
    return *this;
  }

  ~Tekst () { delete [] txt; }
};

int main () {
  Tekst a ("Dobar dan.");                // Stvaranje i inicijalizacija.
  Tekst b = Tekst ("Zdravo.");
  Tekst c (a), d = b;
  a = b;                                 // Dodela vrednosti.
}


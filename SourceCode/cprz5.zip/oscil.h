// Definicija klase za prigusene oscilacije (Oscil).

#ifndef _oscil_h_
#define _oscil_h_

#include "fct.h"
#include <cmath>
using namespace std;

namespace Funkcije {
  class Oscil: public Fct {
  public:                               // Racunanje funkcije.
    double operator() (double x) const { return exp(-0.1*x) * sin(x); }
  } ; // class Oscil
} // namespace Funkcije

#endif

// Definicija funkcije integral.

#include "integ.h"

double Funkcije::integral (const Fct& f, double a, double b) {
  try {                             // Pokusaj tacnog racunanja.
    return f.I(b) - f.I(a);
  } catch (G_nema_integral) {       // Priblizno racunanje.
    const int N = 1000;
    double dx=(b-a) / N;
    double y = 0;
    for (int i=0; i<N; y+=f(a+dx*i++));
    return y * dx;
  }
}

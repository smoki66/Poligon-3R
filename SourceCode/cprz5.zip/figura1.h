// Definicija klase geometrijskih figura (Figura).

#ifndef _figura1_h_
#define _figura1_h_

#include "tacka2.h"

class Figura {
  Tacka T;                                  // Teziste figure.
public:
  Figura (const Tacka& tt=ORG): T(tt)  {}   // Konstruktor.
  virtual ~Figura () {}                     // Destruktor.
  virtual Figura* kopija () const =0;       // Stvaranje kopije.
  Figura& postavi (Real xx, Real yy)        // Postavljanje figure.
    { T = Tacka (xx, yy); return *this; }
  Figura& pomeri (Real dx, Real dy)         // Pomeranje figure.
    { T = Tacka ( T.aps() + dx, T.ord() + dy); return *this; }
  virtual Real O () const =0 ;              // Obim.
  virtual Real P () const =0 ;              // Povrsina.
protected:
  virtual void citaj (istream& ut)       { ut >> T; }          // Citanje.
  virtual void pisi  (ostream& it) const { it << "T=" << T; }  // Pisanje.
  friend istream& operator>> (istream& ut, Figura& ff) //Uopsteno citanje
    { ff.citaj (ut); return ut; }                              //    i
  friend ostream& operator<< (ostream& it, const Figura& ff)   // pisanje.
    { ff.pisi  (it); return it; }
} ;

#endif

// Prikaz rada potprograma qsort.

#include <iostream>
#include <cstdlib>
using namespace std;

namespace sort {
  void qsort (int[], int);
}

int main () {
  while (true) {
    int n; cout << "\n\nDuzina niza? "; cin >> n;
  if (n <= 0) break;
    int* a = new int [n];
    cout << "\nPocetni niz:\n\n";
    for (int i=0; i<n; i++)
      cout << (a[i] = rand() / ((double)RAND_MAX+1) * 10)
           << ((i%30==29 || i==n-1) ? '\n' : ' ');

    sort::qsort (a, n);

    cout << "\nSortirani niz:\n\n";
    for (int i=0; i<n; i++)
      cout << a[i] << ((i%30==29 || i==n-1) ? '\n' : ' ');
    delete [] a;
  }
}

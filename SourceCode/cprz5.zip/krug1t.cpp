// Program za ispitivanje klase Krug.

#include "krug1.h"
#include <iostream>
using namespace std;

int main () {
  Krug* krugovi [100]; int n = 0;
  while (true) {
    cout << "Poluprecnik? "; double r; cin >> r;
  if (r <= 0) break;
    cout << "Koordinate centra? "; double x, y; cin >> x >> y;
    if (Krug::moze (r, x, y)) {
      krugovi[n++] = new Krug (r, x, y);
    } else cout << "*** Ne moze da se smesti! ***\n\a";
  }
  Krug::pisi_sve ();
}

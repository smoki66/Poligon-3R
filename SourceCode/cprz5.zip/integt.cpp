// Program za ispitivanje klasa za racunanje integrala.

#include "fct.h"
#include "sin2.h"
#include "oscil.h"
#include "poli2.h"
#include "log.h"
#include "integ.h"
#include "greska.h"
#include <iostream>
#include <new>
using namespace std;
using namespace Funkcije;

int main () {
  while (true) {
    Fct* fct = 0;
    try {
      cout << "\nFunkcija (S, O, L, P, .)? ";
      char izb; cin >> izb;
      switch (izb) {
        case 's': case 'S': fct = new Sin;   break;
        case 'o': case 'O': fct = new Oscil; break;
        case 'l': case 'L': fct = new Log;   break;
        case 'p': case 'P': {
          int n; cout << "Red polinoma? "; cin >> n;
          Poli* p = new Poli (n);
          while (1) {
            cout << "Indeks i vrednost koeficijenta? ";
            int i; double k; cin >> i >> k;
          if (i < 0) break;
            (*p)[i] = k;
          }
          fct = p;
          break;
        }
        case '.': break;
        default: throw "Nedozvoljen izbor";
      }
  if (!fct) break;
      double a, b; cout << "Interval? "; cin >> a >> b;
      cout << "Integral= " << integral(*fct,a,b) << endl;
    } catch (const Greska& g) {
      cout << g;
    } catch (Vekt::Greska g) {
      cout << "\n*** Greska Vektor::" << g << " ***\n\a";
    } catch (const char* g) {
      cout << "\n*** " << g << " ***\n\a";
    } catch (bad_alloc) {
      cout << "\n*** Nesupesna dodela memorije ***\n\a";
    }
    delete fct;
  }
}

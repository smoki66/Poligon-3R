// Definicija klase kvadrata (Kvadrat).

#ifndef _kvadrat_h_
#define _kvadrat_h_

#include "figura1.h"

class Kvadrat : public Figura {
  Real a;                                  // Osnovica.
public:
  Kvadrat (Real aa=1, const Tacka& tt=ORG) // Konstruktor.
    : Figura(tt) { a = aa; }
  Kvadrat* kopija () const                 // Stvaranje kopije.
    { return new Kvadrat (*this); }
  Real O () const { return 4 * a; }        // Obim.
  Real P () const { return a * a; }        // Povrsina.
private:
  void citaj (istream& ut) ;               // Citanje.
  void pisi  (ostream& it) const ;         // Pisanje.
} ;

#endif

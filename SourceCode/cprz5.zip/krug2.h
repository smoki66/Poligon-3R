// Definicija klase krugova (Krug).

#ifndef _krug2_h_
#define _krug2_h_

#include "figura1.h"

namespace { const Real PI = 3.14159265359; }

class Krug : public Figura {
  Real r;                                  // Poluprecnik.
public:
  Krug (Real rr=1, const Tacka& tt=ORG)    // Konstruktor.
    : Figura (tt) { r = rr; }
  Krug* kopija () const                    // Stvaranje kopije.
    { return new Krug (*this); }
  Real O () const { return 2 * r * PI; }   // Obim.
  Real P () const { return r * r * PI; }   // Povrsina.
private:
  void citaj (istream& ut) ;               // Citanje.
  void pisi  (ostream& it) const ;         // Pisanje.
} ;

#endif

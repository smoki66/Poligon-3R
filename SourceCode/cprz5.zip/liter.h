// Definicija klase iteratora za liste (LIter).

#ifndef _liter_h_
#define _liter_h_

#include "iter.h"
#include "lista.h"

class LIter: public Iter {
  Lista* lst;                                // Pokazivac na listu.
  mutable Lista::Elem *preth, *tek;          // Prethodni i tekuci element.
public:
  LIter (const Lista* lis)                   // Stvaranje iteratora.
    { lst = const_cast<Lista*>(lis); preth=0; tek = lst->prvi;}
  bool ima () const                          // Ima li jo� elemenata?
    { return tek != 0; }
  LIter& poc ()                              // Pomeranje na pocetak.
    { preth = 0; tek = lst->prvi; return *this; }
  LIter& operator++ () {                     // Pomeranje korak napred.
    if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
    preth = tek; tek = tek->sled;
    return *this;
  }
  Figura* operator-> () {                    // Pokazivac na figuru.
    if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
    return tek->fig;
  }
  LIter& operator+= (Figura *fig) {          // Umetanje figure.
    Lista::Elem* novi = new Lista::Elem (fig, tek);
    (!preth ? lst->prvi : preth->sled) = tek;
    if (!tek) lst->posl = novi;
    return *this;
  }
  LIter& operator-= (Figura*& fig) {         // Vadenje figure.
    if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
    fig = tek->fig;
    Lista::Elem* stari = tek;
    tek = (!preth ? lst->prvi : preth->sled) = tek->sled;
    delete stari; lst->vel--;
    return *this;
  }

  // Varijante ranijih operacija za nepromenljive liste.
  const LIter& poc () const                  // Pomeranje na pocetak.
    { return const_cast<LIter*>(this)->poc(); }
  const LIter& operator++ () const           // Pomeranje korak napred.
    { return ++ const_cast<LIter&>(*this); }
  const Figura* operator-> () const          // Pokazivac na figuru.
    { return (const_cast<LIter*>(this))->operator->(); }
};

#endif

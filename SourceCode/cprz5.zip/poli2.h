// Definicija klase za polinome (Poli).

#ifndef _poli2_h_
#define _poli2_h_

#include "fct.h"
#include "vekt.h"

namespace Funkcije {
  class Poli: public Fct {
    Vekt a;                                     // Vektor koeficijenata.
  public:
    Poli () : a () {}                           // Konstruktori.
    explicit Poli (int n) : a (0, n) {}
    double& operator[] (int i) { return a[i]; } // Dohvatanje koeficijenta.
    const double& operator[] (int i) const { return a[i]; }
    int red () const { return a.max_ind (); }   // Red polinoma.
    double operator() (double x) const;         // Vrednost polinoma.
    double I (double x) const;                  // Vrednost integrala.
 } ; // class Poli
} // namespace Funkcije

#endif

// Definicije metoda uz klasu Krug.

#include "krug2.h"

void Krug::citaj (istream& ut)               // Citanje.
  { Figura::citaj (ut); ut >> r ; }

void Krug::pisi  (ostream& it) const {       // Pisanje.
  it << "krug    [";
  Figura::pisi (it);
  it << ", r=" << r << ", O=" << O() << ", P=" << P() << ']';
}

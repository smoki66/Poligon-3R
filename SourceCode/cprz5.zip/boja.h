// Definicja klase za boje (Boja).

#ifndef _boja_h_
#define _boja_h_

#include "greska.h"
using Usluge::Greska;
#include <iostream>
using namespace std;

namespace Figure {
  class G_neispravna_boja: public Greska { // KLASA ZA GRESKU:
    double c, z, p;                        // Nedozvoljene komponente.
  public:                                  // Konstruktori.
    G_neispravna_boja (): Greska ("Nedozvoljene komponente boje") {}
    G_neispravna_boja (double cc, double zz, double pp): Greska ()
      { c = cc; z = zz; p = pp; }
  private:
    void pisi (ostream& it) const {       // Pisanje poruke.
      if (ima_poruke ()) Greska::pisi(it);
      else it << "\n*** Neispravna boja: ("
               << c << ',' << z << ',' << p << ") ***\a\n";
    }                                      // Dohv. nedozv. komp.
    double uzmi_c () const { return ima_poruke() ? 0 : c; }
    double uzmi_z () const { return ima_poruke() ? 0 : z; }
    double uzmi_p () const { return ima_poruke() ? 0 : p; }
  } ; // class G_neispravna_boja

  class Boja {                             // KLASA ZA BOJU:
    double c, z, p;                        // Komponente boje.
  public:
    Boja () { c = z = p = 1; }             // Konstruktori.
    Boja (double cc, double zz, double pp) {
      if (cc<0 || cc>1 || zz<0 || zz>1 || pp<0 || pp>1)
        throw G_neispravna_boja (cc, zz, pp);
      c = cc; z = zz; p = pp;
    }
    double uzmi_c () const { return c; }   // Dohvatanje komponenata boje.
    double uzmi_z () const { return z; }
    double uzmi_p () const { return p; }
    friend istream& operator>> (istream& ut, Boja& b) {       // Citanje.
      double c, z, p; ut >> c >> z >> p;
      b = Boja (c, z, p); return ut;
    }
    friend ostream& operator<< (ostream& it, const Boja& b)   // Pisanje.
      { return it << '(' << b.c << ',' << b.z << ',' << b.p << ')'; }
  } ; // class Boja
} // namespace Figure

#endif

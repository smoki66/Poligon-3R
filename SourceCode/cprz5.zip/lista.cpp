// Definicije metoda uz klasu Lista.

#include "lista.h"
#include "liter.h"

void Lista::kopiraj (const Lista& lst){      // Kopiranje u listu.
  prvi = posl = 0; vel = lst.vel;
  for (Elem* tek=lst.prvi; tek; tek=tek->sled)
    posl = (!prvi ? prvi : posl->sled) = new Elem (tek->fig->kopija());
}

void Lista::brisi () {                       // Unistavanje liste.
  while (prvi) {
    Elem* stari = prvi; prvi = prvi->sled;
    delete stari->fig; delete stari;
  }
  posl = 0; vel = 0;
}

Figura*& Lista::operator[] (int ind) {        // Dohvatanje figure.
  if (ind<0 || ind >= vel) greska (G_IND);
  Elem* tek = prvi;
  for (int i=0; i<ind; i++) tek = tek->sled;
  return tek->fig;
}

Iter* Lista::iter ()                           // Stvaranje iteratora.
  { return new LIter (this); }
const Iter* Lista::iter () const
  { return new LIter (this); }

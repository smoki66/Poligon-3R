#include "krug3.h"
using namespace Figure;
using namespace std;

int main () {
  Krug k1 (1, Tacka(1,1), Boja (1,1,1)); cout << k1 << endl;
  Krug k2 (2, Tacka(2,2), Boja (0,0,0)); cout << k2 << endl;
  Krug k3 (k1);                          cout << k3 << endl;
  k3 = k2;                               cout << k3 << endl;
}

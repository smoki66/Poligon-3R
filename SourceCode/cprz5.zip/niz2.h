// Definicija klase za nizove figura (Niz).

#ifndef _niz2_h_
#define _niz2_h_

#include "zbirka.h"

class Niz: public Zbirka {
  friend class NIter;                        // Iterator za nizove.
  Figura** niz;                              // Elementi niza.
  int kap, vel;                              // Kapacitet i velicina.
  void kopiraj (const Niz& n);               // Kopiranje u niz.
  void brisi () { ~*this; delete [] niz; }   // Unistavanje niza.
public:
  explicit Niz (int k=10)                    // Stvaranje praznog niza.
    { niz = new Figura* [kap = k]; vel = 0; }
  Niz (const Niz& n) { kopiraj (n); }        // Konstruktor kopije.
  ~Niz () { brisi (); }                      // Destruktor.
  Niz& operator= (const Niz& n) {            // Dodela vrednosti.
    if (this != &n) { brisi (); kopiraj (n); }
    return *this;
  }
  int operator+ () const { return vel; }     // Broj elemenata zbirke.
  Niz& operator+= (Figura* fig);             // Dodavanje figure.
  Figura*& operator[] (int ind) {            // Dohvatanje figure.
    if (ind<0 || ind >= vel) greska (G_IND);
    return niz[ind];
  }
  const Figura* operator[] (int ind) const
    { return const_cast<Niz&>(*this)[ind]; }
  Niz& operator~ () ;                        // Praznjenje niza.
  Niz* kopija () const                       // Stvaranje kopije niza.
    { return new Niz (*this); }
  Iter* iter () ;                            // Stvaranje iteratora.
  const Iter *iter () const;
};

#endif
              
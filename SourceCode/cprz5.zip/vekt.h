// Definicija klase vektora realnih brojeva (Vekt).

class Vekt {                            // Polja:
  int min, max;                         //   granice indeksa,
  int duz;                              //   broj elemenata,
  double* niz;                          //   niz elemenata.
                                        // Pomocne metode:
  void pravi (int poc, int kra) ;       //   stvaranje vektora,
  void kopiraj (const Vekt& v) ;        //   kopiranje u vektor,
  void brisi () ;                       //   uni�tavanje vektora.

public:                                 // Kodovi gresaka:
  enum Greska { OPSEG,                  //   neispravan opseg indeksa,
                PRAZAN,                 //   vektor je prazan,
                INDEKS,                 //   indeks je izvan opsega,
                DUZINA } ;              //   neusagla�ene duzine vektora.
                                        // Konstruktori:
  Vekt () { niz = 0; }                  //   prazan niz,
  explicit Vekt (int kra) {pravi(1,kra);} // podrazumevani pocetni indeks,
  Vekt (int poc, int kra){pravi(poc,kra);}// sa zadatim indeksima,
  Vekt (const Vekt& v) { kopiraj (v); } //   kopije.
  ~Vekt () { brisi (); }                // Destruktor.
  Vekt& operator= (const Vekt& v) ;     // Dodela vrednosti.
  double& operator[] (int ind) ;        // Pristup elementu.
  const double& operator[] (int ind) const ;
  friend double operator*(const Vekt& v,// Skalarni proizvod.
                          const Vekt& w) ;
  int min_ind () const { return min; }  // Najmanji indeks.
  int max_ind () const { return max; }  // Najveci indeks.
} ;

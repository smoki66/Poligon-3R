// Program za ispitivanje klasa obojenih geometrijskih figura.

#include "krug3.h"
#include "pravoug2.h"
#include "trougao2.h"
#include "mnogoug.h"
#include "crtez.h"
using namespace Figure;
#include <iomanip>
using namespace std;

Figura* citaj () {                 // CITANJE JEDNE FIGURE:
  static string marg = "";         // Leva margina dijaloga.
  cout << endl << marg
                   << "Vrsta (K,P,T,M,C,.)? "; char vrs; cin >> vrs;
  switch (vrs) {
    case   'k': case 'K': {        // Citanje kruga.
      cout << marg << "Boja figure (c,z,p)? "; Boja   b; cin >> b;
      cout << marg << "Centar (x,y)?        "; Tacka  C; cin >> C;
      cout << marg << "Poluprecnik?         "; double r; cin >> r;
      return new Krug (r, C, b);
    } case 'p': case 'P': {        // Citanje pravougaonika.
      cout << marg << "Boja figure (c,z,p)? "; Boja   b; cin >> b;
      cout << marg << "Jedno teme (x,y)?    "; Tacka  A; cin >> A;
      cout << marg << "Suprotno teme (x,y)? "; Tacka  C; cin >> C;
      return new Pravoug (A, C, b);
    } case 't': case 'T': {        // Citanje trougla.
      cout << marg << "Boja figure (c,z,p)? "; Boja   b; cin >> b;
      cout << marg << "Prvo  teme (x,y)?    "; Tacka  A; cin >> A;
      cout << marg << "Drugo teme (x,y)?    "; Tacka  B; cin >> B;
      cout << marg << "Trece teme (x,y)?    "; Tacka  C; cin >> C;
      return new Trougao (A, B, C, b);
    } case 'm': case 'M': {        // Citanje mnogougla.
      cout << marg << "Boja figure (c,z,p)? "; Boja   b; cin >> b;
      cout << marg << "Broj temena?         "; int    n; cin >> n;
      vector<Tacka> temena (n);
      for (int i=0; i<n; i++) {
        cout << marg << setw(2) << (i+1) << ". teme (x,y)?      ";
        cin >> temena[i];
      }
      return new Mnogoug (temena, b);
    } case 'c': case 'C': {        // Citanje crteza.
      cout << marg << "Boja figure (c,z,p)? "; Boja   b; cin >> b;
      cout << marg << "Dole-levo (x,y)?     "; Tacka  A; cin >> A;
      cout << marg << "Sirina, visina?      ";
      double sir, vis; cin >> sir >> vis;
      Crtez* crt = new Crtez (A, sir, vis, b);
      marg += "  ";                                // Citanje delova
      while (Figura* fig = citaj ()) *crt += fig;  // crteza povecanom
      marg.erase(0,2);                             // marginom.
      return crt;
    } default: return 0;           // "Prazna" figura.
  }
}

int main () {                      // GLAVNA FUNKCIJA:
  Figura *fig = citaj ();
  cout << endl << *fig << endl << endl;
  while (true) {
    cout << "Tacka (x,y)? "; Tacka T; cin >> T;
  if (T.uzmi_x() == 1E38) break;
    try {
      cout << "Boja tacke:  " << fig->boja (T) << endl;
    } catch (G_tacka_ne_pripada g) { cout << g; }
  }
}

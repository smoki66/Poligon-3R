// Definisanje konverzija tipova.

#include <iostream>
#include <cmath>
using namespace std;

class Kompl {
  double re, im;
public:
  Kompl (double r=0, double i=0) { re=r; im=i; } // Inic. ili konverzija.
  operator double(){ return sqrt(re*re+im*im); } // Konverzija u double.
  friend double real (Kompl z) { return z.re; }  // Realni deo.
  friend double imag (Kompl z) { return z.im; }  // Imaginarni deo.
  Kompl operator+ (Kompl z)                      // Sabiranje.
    { z.re += re; z.im += im; return z; }
  friend ostream& operator<< (ostream& it, const Kompl& z)
    { return it << '(' << z.re << ',' << z.im << ')'; }
};

int main () {
  Kompl a (1, 2);      cout << "a       = " << a               << endl;
  Kompl b = a;         cout << "b       = " << b               << endl;
  Kompl c = 5;         cout << "c       = " << c               << endl;
                       cout << "a+b     = " << a + b           << endl;
                       cout << "a+3     = " << a + (Kompl)3    << endl;
                       cout << "|a|+3   = " << (double)a + 3   << endl;
                       cout << "a+(3,4) = " << a + Kompl (3,4) << endl;
                       cout << "dble(a) = " << (double)a       << endl;
  double d=Kompl(3,4); cout << "d       = " << d               << endl;
}

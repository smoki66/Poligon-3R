// Klasa sa destruktorom.

class Tekst {
  char* niz;                          // Pokazivac na sam Tekst.
public:
  Tekst () { niz = 0; }               // Inicijalizacija praznog niza.
  Tekst (const char*) ;               // Inicijalizacija nizom znakova.
  Tekst (const Tekst&) ;              // Inicijalizacija tipom Tekst.
  ~Tekst () ;                         // Unistavanje objekta tipa Tekst.
  void pisi () const;                 // Ispisivanje niza.
} ;

#include <cstring>
#include <iostream>
using namespace std;

Tekst::Tekst (const char* t)
  { niz = new char [strlen(t)+1]; strcpy (niz, t); }

Tekst::Tekst (const Tekst& t)
  { niz = new char [strlen(t.niz)+1]; strcpy (niz, t.niz); }

Tekst::~Tekst () { delete [] niz; niz = 0; }

void Tekst::pisi () const { cout << niz; }

int main () {
  Tekst pozdrav ("Pozdrav svima");   // Poziva se Tekst (char*).
  Tekst a = pozdrav;                 // Poziva se Tekst (Tekst&).
  Tekst b;                           // Poziva se Tekst ().
  cout << "pozdrav = "; pozdrav.pisi (); cout << endl;
  cout << "a       = "; a.pisi ()      ; cout << endl;
} // Ovde se poziva destruktor za sva tri objekta.

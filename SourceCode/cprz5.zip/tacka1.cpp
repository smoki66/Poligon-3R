// Definicije metoda klase Tacka.

#include <cmath>
#include <iostream>
using namespace std;
#include "tacka1.h"

// Odstojanje tekuce tacke od koordinatnog pocetka.
double Tacka::poteg () const { return sqrt (x*x + y*y); }

// Nagib potega u odnosu na x-osu.
double Tacka::nagib () const { return (x==0 && y==0) ? 0 : atan2(y,x); }

// Odstojanje tekuce tacke od tacke a.
double Tacka::rastojanje (Tacka a) const
  { return sqrt(pow(x-a.x,2) + pow(y-a.y,2)); }

// Najbliza tacka u nizu tacaka a u odnosu na tekucu tacku.
Tacka Tacka::najbliza (const Tacka* a, int n) const {
  Tacka t = a[0]; double r, m = rastojanje (t);
  for (int i=1; i<n; i++) if ((r=rastojanje(a[i]))<m) {m = r; t = a[i];}
  return t;
}

// Citanje koordinata tekuce tacke s glavnog ulaza.
void Tacka::citaj () { cin >> x >> y; }

// Pisanje koordinata tekuce tacke na glavnom izlazu.
void Tacka::pisi () const { cout << '(' << x << ',' << y << ')'; }

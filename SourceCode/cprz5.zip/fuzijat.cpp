// Ispitivanje genericke funkcije za fuziju nizova.

#include <iostream>
#include "fuzija.h"
#include "tacka3.h"
#include "pravoug1.h"
using namespace std;

int main () {
  int na, nb, nc, i;

  { cout << "\nFuzija nizova celih brojeva:\n\n";
    cin >> na; int* a = new int [na]; cout << "Prvi  niz:";
    for (i=0; i<na; i++){cin >> a[i]; cout << ' ' << a[i];} cout << endl;
    cin >> nb; int* b = new int [nb]; cout << "Drugi niz:";
    for (i=0; i<nb; i++){cin >> b[i]; cout << ' ' << b[i];} cout << endl;
    int* c; fuzija<int> (a, na, b, nb, c, nc);
    cout << "Fuzija   :";
    for (i=0; i<nc; i++) {cout << ' ' << c[i];} cout << endl;
    delete [] a; delete [] b; delete [] c;
  }

  { cout << "\nFuzija nizova tacaka:\n\n";
    cin >> na; Tacka* a = new Tacka [na]; cout << "Prvi  niz:";
    for (i=0; i<na; i++){cin >> a[i]; cout << ' ' << a[i];} cout << endl;
    cin >> nb; Tacka* b = new Tacka [nb]; cout << "Drugi niz:";
    for (i=0; i<nb; i++){cin >> b[i]; cout << ' ' << b[i];} cout << endl;
    Tacka* c; fuzija<Tacka> (a, na, b, nb, c, nc);
    cout << "Fuzija   :";
    for (i=0; i<nc; i++) {cout << ' ' << c[i];} cout << endl;
    delete [] a; delete [] b; delete [] c;
  }

  { cout << "\nFuzija nizova pravougaonika:\n\n";
    cin >> na; Pravoug* a = new Pravoug [na]; cout << "Prvi  niz:";
    for (i=0; i<na; i++){cin >> a[i]; cout << ' ' << a[i];} cout << endl;
    cin >> nb; Pravoug* b = new Pravoug [nb]; cout << "Drugi niz:";
    for (i=0; i<nb; i++){cin >> b[i]; cout << ' ' << b[i];} cout << endl;
    Pravoug* c; fuzija<Pravoug> (a, na, b, nb, c, nc);
    cout << "Fuzija   :";
    for (i=0; i<nc; i++) {cout << ' ' << c[i];} cout << endl;
    delete [] a; delete [] b; delete [] c;
  }
}

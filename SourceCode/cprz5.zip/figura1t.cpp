// Program za ispitivanje klasa za geometrijske figure.

#include "krug2.h"
#include "kvadrat.h"
#include "trougao1.h"
#include <iostream>
using namespace std;

int main () {

  // Element liste figura.
  struct Elem {
    Figura* fig; Elem* sled;
    Elem (Figura* ff, Elem* ss=0) { fig = ff; sled = ss; }
    ~Elem () { delete fig; }
  };

  Elem *prvi = 0, *posl = 0;

  // Stvaranje liste figura citajuci s glavnog ulaza.
  for (bool dalje=true; dalje; ) {
    Figura* pf;
    char vrsta; cin >> vrsta;
    switch (vrsta) {
      case 'o': pf = new Krug;    break;
      case 'k': pf = new Kvadrat; break;
      case 't': pf = new Trougao; break;
      default: dalje = false;
    }
    if (dalje) {
      cin >> *pf;
      Elem* novi = new Elem (pf);
      posl = (!prvi ? prvi : posl->sled) = novi;
    }
  }

  // Prikazivanje sadrzaja liste na glavnom izlazu.
  for (Elem* tek=prvi; tek; tek=tek->sled) cout << *tek->fig << endl;

  // Citanje pomeraja za pomeranje figura.
  Real dx, dy; cin >> dx >> dy;
               cout << "\ndx, dy= " << dx << ", " << dy << "\n\n";

  // Stvaranje kopije liste uz pomeranje figura.
  Elem *poc = 0, *kraj = 0;
  for (Elem* tek=prvi; tek; tek=tek->sled) {
    Elem* novi = new Elem (tek->fig->kopija());
    novi->fig->pomeri(dx,dy);
    kraj = (!poc ? poc : kraj->sled) = novi;
  }

  // Unistavanje prve liste.
  while (prvi) { Elem* stari=prvi; prvi=prvi->sled; delete stari; }
  posl = 0;

  // Prikazivanje sadrzaja kopirane liste na glavnom izlazu.
  for (Elem* tek=poc; tek; tek=tek->sled) cout << *tek->fig << endl;
}

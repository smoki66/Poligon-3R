// Preklapanje operatora [].

#include <iostream>
#include <cstdlib>
using namespace std;

class Niz {
  int poc, kraj;                     // Opseg indeksa.
  double* a;                         // Elementi niza.
  void kopiraj (const Niz&);         // Kopiranje.
public:
  Niz (int min, int max) {           // Konstruktori.
    if (min > max) exit (1);
    a = new double [(kraj=max)-(poc=min)+1];
  }
  Niz (const Niz& niz) { kopiraj (niz); }
  ~Niz () { delete [] a; }           // Destruktor.
  Niz& operator= (const Niz& niz) {  // Dodela vrednosti.
    if (this != &niz) { delete [] a; kopiraj (niz); }
    return *this;
  }
  double& operator[] (int i) {       // DOHVATANJE ELEMENTA.
    if (i<poc || i>kraj) exit (2);
    return a[i-poc];
  }
  const double& operator[] (int i) const {
    if (i<poc || i>kraj) exit (2);
    return a[i-poc];
  }
};

void Niz::kopiraj (const Niz& niz) { // Kopiranje.
  a = new double [(kraj=niz.kraj)-(poc=niz.poc)+1];
  for (int i=0; i<kraj-poc+1; i++) a[i] = niz.a[i];
}

int main () {
  Niz niz (-5, 5);
  for (int i=-5; i<=5; i++) niz[i]=i;
//*(niz+4) = 4;       // GRESKA: ne vazi adresna aritmetika!
  const Niz cniz = niz;
//cniz = niz;         // GRESKA: menjanje celog nepromenljivog niza!
//cniz[2] = 55;       // GRESKA: menjanje dela nepromenljivog niza!
  double a = cniz[2]; // U redu: uzimanje je dozvoljeno.
}
// Definicije metoda uz klasu Red.

#include "red.h"

void Red::kopiraj (const Red& r) {   // Kopiranje reda.
  prvi = posl = 0; duz = r.duz;
  for (Elem* tek=r.prvi; tek; tek=tek->sled)
    posl = (!prvi ? prvi : posl->sled) = new  Elem (tek->pod);
}

void Red::brisi () {                 // Brisanje svih elemenata reda.
  while (prvi) { Elem* stari=prvi; prvi = prvi->sled; delete stari; }
  posl = 0; duz = 0;
}

Red& Red::operator+= (const Red& r) {      // Dodavanje reda.
  Red s (r);
  (!prvi ? prvi : posl->sled) = s.prvi;
  posl = s.posl; duz += s.duz;
  s.prvi = s.posl = 0; s.duz = 0;
  return *this;
}

Red Red::operator+ (const Red& r) const    // Spoj dva reda.
  // Ne moze "inline" zbog vracanja kopije lokalnog objekta!
  { Red s (*this); s += r; return s; }

int Red::operator-- () {           // Brisanje prvog elementa iz reda.
  if (duz == 0) return 0;
  int pod = prvi->pod;
  Elem* stari = prvi;
  if ((prvi = prvi->sled) == 0) posl = 0;
  delete stari;
  duz--;
  return pod;
}

Red Red::operator- (int k) const { // Red bez elemenata jednakih k.
  Red r;
  for (Elem* tek=prvi; tek; tek=tek->sled) if (tek->pod != k) r+=tek->pod;
  return r;
}

// Definicija klase za uredjene skupove (Skup).

class Skup {
  int vel; double* niz;                     // Velicina i elementi skupa.
  void kopiraj (const Skup&);               // Kopiranje skupa.
  void brisi () { delete [] niz; niz = 0; vel = 0; } // Praznjenje skupa.
public:
  Skup () { niz = 0; vel = 0; }             // Stvaranje praznog skupa.
  Skup (double a) {                         // Konverzija broja u skup.
    niz = new double [vel = 1];
    niz[0] = a;
  }
  Skup (const Skup& s) { kopiraj (s); }     // Inicijalizacija skupom.
  ~Skup () { brisi (); }                    // Unistavanje skupa.
  void presek (const Skup&, const Skup&);   // Presek dva skupa.
  void razlika(const Skup&, const Skup&);   // Razlika dva skupa.
  void unija  (const Skup&, const Skup&);   // Unija dva skupa.
  void pisi () const;                       // Ispisivanje skupa.
  void citaj ();                            // Citanje skupa.
  int velicina () const { return vel; }     // Velicina skupa.
} ;

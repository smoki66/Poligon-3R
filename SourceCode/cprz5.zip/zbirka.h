// Abstraktna klasa za zirke figura (Zbirka).

#ifndef _zbirka_h_
#define _zbirka_h_

#include <iostream>
using namespace std;

#include "figura1.h"                         // Definicja klase Figura.
class Iter;                                  // Deklaracija klase Iter.

class Zbirka {
public:
  virtual ~Zbirka () {}                      // Virtuelni destruktor.
  virtual int operator+ () const =0;         // Broj elemenata zbirke.
  virtual Zbirka& operator+=(Figura* fig)=0; // Dodavanje figure.
  friend Zbirka& operator+= (Zbirka& zb, const Figura& fig)
    { return zb += fig.kopija (); }
  virtual Figura*& operator[] (int ind) =0;  // Dohvatanje figure.
  virtual const Figura* operator[] (int ind) const =0;
  virtual Zbirka& operator~ () =0;           // Praznjenje zbirke.
  virtual Zbirka* kopija () const =0;        // Stvaranje kopije zbirke.
  friend ostream& operator<<                 // Pisanje zbirke.
    (ostream& it, const Zbirka& zb);
  virtual Iter* iter () =0;                  // Stvaranje iteratora.
  virtual const Iter* iter () const =0;

  enum { G_IND, G_TEK };                     // Sifre gresaka.
  static void greska (int g);                // Prekid programa.
};

#endif

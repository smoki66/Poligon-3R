// Deklaracija funkcije za izracunavanje odredjenog integrala (integral).

#ifndef _integ_h_
#define _integ_h_

#include "fct.h"

namespace Funkcije {
  double integral (const Fct& f, double a, double b);
} // namespace Funkcije

#endif
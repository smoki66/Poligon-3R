// Definicije metoda klase Stek.

#include "stek1.h"
#include <cstdlib>
using namespace std;

Stek* Stek::vrh = 0;           // Definicija vrh-a s inicijalizacijom.

void Stek::stavi (int i) {     // Stavljanje novog podatka vrh na steka:
  Stek* novi  = new Stek;      //   - dodela memorije,
  if (! novi) exit (1);        //   - prekid programa ako nije uspela,
  novi->broj  = i;             //   - smestanje podatka u element,
  novi->preth = vrh;           //   - ukljucivanje elementa u listu.
  vrh = novi;
}

int Stek::uzmi () {            // Uzimanje podatka s vrha steka:
  if (! vrh) exit (2);         //   - prekid programa ako je stek prazan,
  int i = vrh->broj;           //   - pamcenje podatka s vrha steka,
  Stek* stari = vrh;           //   - iskljucivanje elementa iz liste,
  vrh = vrh->preth;
  delete stari;                //   - oslobadjanje dodeljene memorije,
  return i;                    //   - vracanje upamcenog podatka.
}

void Stek::prazni () { while (vrh) uzmi (); }  // Praznjenje steka.

// Definicije metoda i funkcija uz klasu Vekt.

#include "vekt.h"

void Vekt::pravi (int poc, int kra) {             // Stvaranje vektora.
  if ((min=poc) > (max=kra)) throw OPSEG;
  niz = new double [duz=kra-poc+1];
  for (int i=0; i<duz; niz[i++]=0) ;
}

void Vekt::kopiraj (const Vekt& v) {              // Kopiranje vektora.
  if (v.niz) {
    niz = new double [duz=(max=v.max)-(min=v.min)+1];
    for (int i=0; i<duz; i++) niz[i] = v.niz[i];
  } else niz = 0;
}

void Vekt::brisi () { delete [] niz; niz = 0; }   // Unistavanje vektora.

Vekt& Vekt::operator= (const Vekt& v) {           // Dodela vrednosti.
  if (this != &v) { brisi (); kopiraj (v); }
  return *this;
}

double& Vekt::operator[] (int ind) {              // Pristup elementu.
  if (! niz)              throw PRAZAN;
  if (ind<min || ind>max) throw INDEKS;
  return niz[ind-min];
}

const double& Vekt::operator[] (int ind) const
  { return (const_cast<Vekt&>(*this))[ind]; }

double operator* (const Vekt& v, const Vekt& w) { // Skalarni proizvod.
  if (! v.niz || ! w.niz) throw Vekt::PRAZAN;
  if (v.duz != w.duz)     throw Vekt::DUZINA;
  double s = 0;
  for (int i=0; i<v.duz; i++) s += v.niz[i] * w.niz[i];
  return s;
}

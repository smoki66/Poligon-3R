// Definicija apstraktne klase za funkcije (Fct).

#ifndef _fct_h_
#define _fct_h_

#include "greska.h"
using Usluge::Greska;

namespace Funkcije {                               // KLASA ZA GRESKU:
  class G_nema_integral: public Greska {
  public:                                          // Konstruktor.
    G_nema_integral(): Greska ("Funkcija nema integral") {}
  } ; // class G_nema_integral

  class Fct {                                      // KLASA ZA FUNKCIJU:
  public:
    virtual ~Fct () {}                             // Virtuelni destruktor.
    virtual double operator() (double x) const =0; // Racunanje funkcije.
    virtual double I (double) const                // Racunanje integrala.
      { throw G_nema_integral(); /*return 0;*/ }
  } ; // class Fct
} // namespace Funkcije

#endif

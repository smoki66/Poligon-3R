// Definicja klase za funkciju logaritam (Log).

#ifndef _log_h_
#define _log_h_

#include "fct.h"
#include "greska.h"
#include <cmath>
using Usluge::Greska;

namespace Funkcije {                              // KLASA ZA GRESKU:
  class G_nema_logaritam: public Greska {
    double x;                                     // Nedozvoljena vrednost.
  public:                                         // Konstruktori.
    G_nema_logaritam (): Greska ("Logaritam negativnog broja") {}
    G_nema_logaritam (double x): Greska () { this->x = x; }
    double uzmiX () const { return ima_poruke() ? 1 : x; } // Uzmi nedozv.
  private:                                                 //   vrednost.
    void pisi (ostream& it) const {
      if (ima_poruke ()) Greska::pisi(it);
      else it << "\n*** Ne postoji logaritam od " << x << " ***\n\a";
    }
  } ; // class G_nema_logaritam

  class Log: public Fct {                         // KLASA ZA FUNKCIJU:
  public:
    double operator() (double x) const {          // Racunanje funkcije.
      if (x <= 0) throw G_nema_logaritam (x);
      return std::log (x);
    }
  } ; // class Log
} // namespace Funkcije

#endif

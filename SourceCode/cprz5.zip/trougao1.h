// Definicija klase trouglova (Trougao).

#ifndef _trougao1_h_
#define _trougao1_h_

#include "figura1.h"

class Trougao : public Figura {
  Real a, b, c;                            // Strane.
public:                                    // Konstruktori:
  Trougao (Real aa=1, const Tacka& tt=ORG)          // jednakostranicni
    : Figura (tt) { a = b = c = aa; }
  Trougao (Real aa, Real bb, const Tacka& tt=ORG)   // jednakokraki
    : Figura (tt) { a = aa; b = c = bb; }
  Trougao (Real aa, Real bb, Real cc, const Tacka& tt=ORG) // opsti
    : Figura (tt) { a = aa; b = bb; c = cc; }
  Trougao* kopija () const                 // Stvaranje kopije.
    { return new Trougao (*this); }
  Real O () const { return a + b + c; }    // Obim.
  Real P () const ;                        // Povrsina.
private:
  void citaj (istream& ut) ;               // Citanje.
  void pisi  (ostream& ot) const ;         // Pisanje.
} ;

#endif

// Definicije metoda uz klasu Kvadrat.

#include "kvadrat.h"

void Kvadrat::citaj (istream& ut)          // Citanje.
  { Figura::citaj (ut); ut >> a ; }

void Kvadrat::pisi  (ostream& it) const {  // Pisanje.
  it << "kvadrat [";
  Figura::pisi (it);
  it << ", a=" << a << ", O=" << O() << ", P=" << P() << ']';
}

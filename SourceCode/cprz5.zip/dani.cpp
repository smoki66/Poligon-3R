// Nabrajanja i preklapanje operatora.

#include <iostream>
using namespace std;

enum Dan { PO, UT, SR, CE, PE, SU, NE};

inline Dan operator+ (Dan d, int k)
  { k = (int(d) + k) % 7; if (k < 0) k += 7; return Dan (k); }
inline Dan operator- (Dan d, int k) { return d + -k; }
inline Dan& operator+= (Dan& d, int k) { return d = d + k; }
inline Dan& operator-= (Dan& d, int k) { return d = d - k; }

inline Dan& operator++ (Dan& d) { return d = Dan (d<NE ? int(d)+1 : PO); }
inline Dan& operator-- (Dan& d) { return d = Dan (d>PO ? int(d)-1 : NE); }
inline Dan operator++ (Dan& d, int) { Dan e(d); ++d; return e; }
inline Dan operator-- (Dan& d, int) { Dan e(d); --d; return e; }

ostream&  operator<< (ostream& it, Dan dan) {
  char* dani[] = {"pon", "uto", "sre", "cet", "pet", "sub", "NED"};
  return it << dani[dan];
}

int main () {
  for (Dan d=PO; d<NE; ++d)
    cout << d << ' ' << d+2 << ' ' << d-2 << endl;
}

// Definicija klase obojenih crteza (Crtez).

#ifndef _crtez_h_
#define _crtez_h_

#include "figura2.h"
#include "pravoug2.h"
#include <vector>
using namespace std;

namespace Figure {
  class Crtez: public Figura {
    Tacka A;                                 // Donje levo teme.
    double s, v;                             // Sirina i visina.
    vector<Figura*> figure;                  // Figure u crtezu.
    void kopiraj (const Crtez& crt);         // Kopiranje crteza.
    void brisi ();                           // Unistavanje crteza.
  public:                                    // Konstruktori.
    explicit Crtez (const Tacka& T=Tacka(),
      double sir=1, double vis=1, Boja bb=Boja()):
      Figura (bb), s(sir), v(vis), A(T) {}
    Crtez (const Crtez& crt): Figura(crt) { kopiraj (crt); }
    Crtez& operator= (const Crtez& crt) {    // Dodela vrednosti.
      if (this != &crt) {
        brisi(); Figura::operator=(crt); kopiraj (crt);
      }
      return *this;
    }
    ~Crtez () { brisi (); }                  // Destruktor.
    Crtez* kopija () const { return new Crtez (*this); } // Kopija.
    Crtez& operator+= (Figura* fig)          // Dodavanje figure.
      { figure.push_back (fig); return *this; }
    Boja boja (const Tacka& T) const;        // Boja tacke.
  private:
    bool pripada (const Tacka& T) const      // Da li tacka pripada?
      { return T < Pravoug(A,Tacka(A.uzmi_x()+s,A.uzmi_y()+v)); }
    void pisi (ostream& it) const;           // Pisanje.
  } ; // class Crtez
} // namespace Figure

#endif

// Definicije metoda uz klasu NIter.

#include "niter.h"

NIter& NIter::operator+= (Figura* fig)  {   // Umetanje figure.
  *niz += 0;
  for (int i=niz->vel-1; i>tek; i--) niz->niz[i] = niz->niz[i-1];
  niz->niz[tek] = fig;
  return *this;
}

NIter& NIter::operator-= (Figura*& fig) {   // Vadjenje figure.
  if (!ima ()) Zbirka::greska (Zbirka::G_TEK);
  fig = niz->niz[tek];
  for (int i=tek+1; i<niz->vel; i++) niz->niz[i-1] = niz->niz[i];
  niz->vel--;
  return *this;
}
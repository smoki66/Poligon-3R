// Definicija metoda uz klasu Mnogoug.

#include "mnogoug.h"
#include "trougao2.h"

bool Figure::Mnogoug::pripada (const Tacka& T) const { // Da li pripada?
  for (unsigned i=1; i<temena.size()-1; i++)
    if (T < Trougao(temena[0],temena[i],temena[i+1])) return true;
  return false;
}

void Figure::Mnogoug::pisi (ostream& it) const {       // Pisanje.
  it << " temena=[";
  for (unsigned i=0; i<temena.size(); i++)
    it << temena[i]
        << (i==temena.size()-1 ? "]" : i%6==2 ? "\n\t" : " ");
}
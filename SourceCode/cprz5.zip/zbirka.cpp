// Definicije metoda uz klasu Zbirka.

#include "zbirka.h"
#include <iostream>
#include <cstdlib>
using namespace std;

ostream& operator<< (ostream& it, const Zbirka& zb) { // Pisanje zbirke.
  it << typeid(zb).name() << '{' << endl;
  for (int i=0; i<+zb; it << "  " << *zb[i++] << endl);
  return it << '}' << endl;
}

void Zbirka::greska (int g) {                         // Prekid programa.
  const char* const poruke[] = {
    "Nedozvoljeni indeks elementa zbirke!",
    "Ne postoji tekuci element zbirke!"
  };
  cout << "GRESKA: " << poruke[g] << endl;
  exit (g+1);
}
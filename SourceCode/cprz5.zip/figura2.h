// Definicija klase obojenih geometrijskih figura (Figura).

#ifndef _figura2_h_
#define _figura2_h_

#include "greska.h"
using Usluge::Greska;
#include "boja.h"
#include "tacka4.h"
#include <iostream>
#include <string>
using namespace std;

namespace Figure {
  class G_tacka_ne_pripada: public Greska { // KLASA ZA GRESKU:
  public:                                   // Konstruktor.
    G_tacka_ne_pripada (): Greska ("Tacka ne pripada figuri") {}
  } ; // class G_tacka_ne_pripada

  class Figura {                            // KLASA ZA FIGURU:
    static int uk_id; // Poslednje korisceni identifikator.
    int id;           // Identifikator figure.
    Boja b;           // Osnovna boja figure.
  public:                                      // Konstruktori.
    explicit Figura (Boja bb=Boja()): b(bb), id(++uk_id) {}
    Figura (const Figura& fig): b(fig.b), id(++uk_id) {}
    Figura& operator= (const Figura& fig)      // Dodela vrednosti.
      { b = fig.b; return *this; }
    virtual ~Figura () {}                      // Virtuelni destruktor.
    virtual Figura* kopija () const =0;        // Dinamicka kopija.
    int uzmi_id () const { return id; }
    Boja boja () const { return b; }           // Osnovna boja figure.
    virtual Boja boja (const Tacka& T) const { // Boja tacke.
      if (! pripada (T)) throw G_tacka_ne_pripada ();
      return b;
    }
  private:
    virtual bool pripada (const Tacka& T) const=0; // Da li tacka pripada?
    friend bool operator< (const Tacka& T, const Figura& fig)
      { return fig.pripada (T); }
    virtual void pisi (ostream& it) const =0;     // Pisanje figure.
    friend ostream& operator<< (ostream& it, const Figura& fig) {
      it << typeid (fig).name()[8] << fig.id << " boja=" << fig.b;
      fig.pisi (it); return it;
    }
  } ; // class Figura
} // namespace Figure

#endif

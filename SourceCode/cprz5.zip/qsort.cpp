// Sortiranje niza brojeva metodom podeli (quick sort).

namespace {
  inline void swap (int& x, int& y)
    { int z = x; x = y; y = z; }

  int part (int a[], int n) {
    int& b = a[n-1], i = -1, j = n-1;
    while (i < j ) {
      do i++; while (a[i] < b);
      do j--; while (j>=0 && a[j]>b);
      swap (a[i], (i<j)?a[j]:b);
    }
    return i;
  }
}

namespace sort {
  void qsort (int a[], int n) {
    if (n > 1) {
      int i = part (a, n);
      qsort (a, i);
      qsort (a+i+1, n-i-1);
    }
  }
}

// Genericka klasa za rastuce uporedjivanje podataka.

template <typename T>
  class Raste {
  public:
    static bool ispred (const T& a, const T& b) { return a < b; }
  } ;

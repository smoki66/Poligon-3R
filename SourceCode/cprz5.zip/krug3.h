// Definicija klase obojenih krugova (Krug).

#ifndef _krug3_h_
#define _krug3_h_

#include "figura2.h"

namespace Figure {
  class Krug: public Figura {
    Tacka  C;                              // Centar.
    double r;                              // Poluprecnik.
  public:                                  // Konstruktor.
    explicit Krug (double rr=1, Tacka cc=Tacka(), Boja bb=Boja())
      : Figura (bb), C(cc), r(rr) {}
    Krug* kopija () const { return new Krug (*this); } // Kopija.
  private:
    bool pripada (const Tacka& T) const    // Da li tacka pripada?
      { return C - T <= r; }
    virtual void pisi (ostream& it) const // Pisanje.
      { it << " C=" << C << " r=" << r; }
  } ; // class Krug
} // namespace Figure

#endif

// Definicije metoda i zajednickih polja klase Krug.

#include "krug1.h"

Krug::Elem* Krug::prvi = 0;             // Pocetak zajednicke liste.

Krug::Krug (double rr, double x, double y) {     // Stvaranje kruga.
  if (! moze (rr, x, y)) exit (1);
  r = rr; c.postavi (x, y);
  prvi = new Elem (this, prvi);
}

Krug::~Krug () {        // Unistavanje kruga (izbacivanje iz liste).
  if (r > 0) {
    Elem *tek = prvi, *preth = 0;
    while (tek->krug != this) { preth = tek; tek = tek->sled; }
    (preth==0 ? prvi : preth->sled) = tek->sled;
    delete tek;
  }
}

bool Krug::moze (double r, double x, double y) { // Moze li stati?
  Krug k; k.r = r; k.c.postavi (x, y);
  for (Elem* tek = prvi; tek; tek = tek -> sled) {
    if (rastojanje (k,* tek->krug) < 0) { k.r = -1; return false; }
  }
  k.r = -1; return true;
}

bool Krug::postavi (double x, double y) {        // Postavljanje kruga.
  if (! moze (r, x, y)) return false;
  c.postavi (x, y);
  return true;
}

bool Krug::pomeri (double dx, double dy) {       // Pomeranje kruga.
  if (! moze (r, c.aps()+dx, c.ord()+dy)) return false;
  c.postavi (c.aps()+dx, c.ord()+dy);
  return true;
}

void Krug::pisi_sve () {                         // Pisanje svih krugova.
  cout << "\nSvi krugovi u memoriji:\n\n";
  for (Elem* tek=prvi; tek; tek=tek->sled)
    { tek->krug->pisi(); cout << endl; }
}


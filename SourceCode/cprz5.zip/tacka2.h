// Definicija klase tacaka (Tacka).

#ifndef _tacka2_h_
#define _tacka2_h_

typedef double Real;           // Tip za realne vrednosti.

#include <iostream>
using namespace std;

class Tacka {
  Real x, y;                                               // Koordinate.
public:
  Tacka (Real xx=0, Real yy=0) { x = xx; y = yy; }         // Konstruktor.
  Real aps () const { return x; }                          // Apscisa.
  Real ord () const { return y; }                          // Ordinata.
  friend istream& operator>> (istream& ut, Tacka& tt)      // Citanje.
    { return ut >> tt.x >> tt.y; }
  friend ostream& operator<< (ostream& it, const Tacka& tt)// Pisanje.
    { return it << '(' << tt.x << ',' << tt.y << ')'; }
} ;

const Tacka ORG;               // Koordinatni pocetak.

#endif

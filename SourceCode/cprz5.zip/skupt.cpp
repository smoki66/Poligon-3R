// Program za ispitivanje klase Skup.

#include "skup.h"
#include <iostream>
using namespace std;

int main () {
  char jos;
  do {
    Skup s1; cout << "niz1? "; s1.citaj ();
    Skup s2; cout << "niz2? "; s2.citaj ();
                               cout << "s1   ="; s1.pisi (); cout << endl;
                               cout << "s2   ="; s2.pisi (); cout << endl;
    Skup s; s.presek (s1, s2); cout << "s1*s2="; s .pisi (); cout << endl;
            s.razlika(s1, s2); cout << "s1-s2="; s .pisi (); cout << endl;
            s.unija  (s1, s2); cout << "s1+s2="; s .pisi (); cout << endl;
    cout << "\nJos? "; cin >> jos;
  } while (jos=='d' || jos=='D');
}
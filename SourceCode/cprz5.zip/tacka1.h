// Definicija klase tacaka u ravni (Tacka).

class Tacka {
  double x, y;
public:
  void   postavi (double a, double b)    // Postavljanje koordinata.
    { x = a; y = b; }
  double aps   () const { return x; }    // Apscisa tacke.
  double ord   () const { return y; }    // Ordinata tacke.
  double poteg () const ;          // Odstojanje od koordinatnog pocetka.
  double nagib () const ;          // Nagib potega u odnosu na x-osu.
  double rastojanje (Tacka) const ;      // Odstojanje od zadate tacke.
  Tacka  najbliza (const Tacka*, int) const;
                                         // Najbliza tacka u nizu tacaka.
  void   citaj () ;                      // Citaj tacku.
  void   pisi  () const;                 // Pisi tacku.
} ;

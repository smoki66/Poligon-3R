// Preklapanje operatora ().

#include <cmath>
#include <iostream>
#include <iomanip>
using namespace std;

class Sin {
  double a, omega, fi;
public:
  explicit Sin (double a=1, double omega=1, double fi=0) {
    this->a = a; this->omega = omega; this->fi = fi;
  }
  double operator() (double x)
    { return a * sin (omega*x+fi); }
};

const double PI = 3.141592;

int main () {
  Sin sin (2, 0.5, PI/6);
  cout << fixed << setprecision(5);
  for (double x=0; x<=2*PI; x+=PI/12)
    cout << setw(10) << x
         << setw(10) << sin(x)
         << setw(10) << std::sin(x) << endl;
}
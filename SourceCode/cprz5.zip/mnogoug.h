// Definicija klase obojenih mnogouglova (Mnogoug).

#ifndef _mnogoug_h_
#define _mnogoug_h_

#include "figura2.h"
#include <vector>
using namespace std;

namespace Figure {
  class Mnogoug: public Figura {
    vector<Tacka> temena;                   // Temena mnogougla.
  public:                                   // Konstruktor.
    explicit Mnogoug (const vector<Tacka>& tem, Boja b=Boja())
      : Figura (b), temena (tem) {}
    Mnogoug* kopija () const { return new Mnogoug (*this); } // Kopija.
  private:
    bool pripada (const Tacka& T) const;    // Da li tacka pripada?
    virtual void pisi (ostream& it) const;  // Pisanje.
  } ; // class Mnogoug
} // namespace Figure

#endif

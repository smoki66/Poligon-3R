// fun.h - Definicija apstarktne klase za funkcije (Fun).

#ifndef _fun_h_
#define _fun_h_

#include <iostream.h>

class Fun {
  virtual void pisi (ostream &d) const =0;
public:
  virtual double operator() (double x) const =0;
  friend ostream & operator<< (ostream &d, const Fun &f)
    { f.pisi (d); return d; }
};

#endif

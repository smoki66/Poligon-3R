// Definicije metoda klase Skup.

#include "skup.h"
#include <iostream>
using namespace std;

void Skup::kopiraj (const Skup &s) {        // Kopiranje skupa.
  niz = new double [vel = s.vel];
  for (int i=0; i<vel; i++) niz[i] = s.niz[i];
}

void Skup::presek (const Skup &s1, const Skup &s2) {  // Presek dva skupa.
  Skup s; s.niz = new double [s1.vel<s2.vel ? s1.vel : s2.vel];
  int i = 0, j = 0, k = 0;
  while (i<s1.vel && j<s2.vel)
    if      (s1.niz[i] < s2.niz[j]) i++;
    else if (s1.niz[i] > s2.niz[j]) j++;
    else                            s.niz[k++] = s1.niz[j++, i++];
  s.vel = k; brisi (); kopiraj (s);
}

void Skup::razlika(const Skup &s1, const Skup &s2) {  // Razlika dva skupa.
  Skup s; s.niz = new double [s1.vel];
  int i = 0, j = 0, k = 0;
  while (i < s1.vel)
    if      (j >= s2.vel)           s.niz[k++] = s1.niz[i++];
    else if (s1.niz[i] < s2.niz[j]) s.niz[k++] = s1.niz[i++];
    else if (s1.niz[i] > s2.niz[j]) j++;
    else                            { i++; j++; }
  s.vel = k; brisi (); kopiraj (s);
}

void Skup::unija  (const Skup &s1, const Skup &s2) {  // Unija dva skupa.
  Skup s; s.niz = new double [s1.vel+s2.vel];
  int i = 0, j = 0, k = 0;
  while (i<s1.vel || j<s2.vel)
    s.niz[k++] = (i<s1.vel && j<s2.vel)
                   ? (s1.niz[i]<s2.niz[j] ? s1.niz[i++] :
                      s1.niz[i]>s2.niz[j] ? s2.niz[j++] :
                                            s1.niz[j++,i++])
                   : (i < s1.vel ? s1.niz[i++] : s2.niz[j++]) ;
  s.vel = k; brisi (); kopiraj (s);
}

void Skup::pisi () const {                            // Ispisivanje skupa.
  cout << '{';
  for (int i=0; i<vel; i++) { cout << niz[i]; if (i < vel-1) cout << ','; }
  cout << '}';
}

void Skup::citaj () {                                 // Citanje skupa.
  brisi ();
  int vel; cin >> vel;
  double broj;
  for (int i=0; i<vel; i++) { cin >> broj; unija (*this, broj); }
}

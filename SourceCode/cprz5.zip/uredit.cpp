// Ispitivanje genericke klase za uredjivanje nizova podataka.

#include "uredi.h"
#include "opada.h"
#include "tacka3.h"
#include "pravoug1.h"
#include <iostream>
using namespace std;

int main () {

  { cout << "\nUredjivanje niza celih brojeva:\n\n";
    int n; cin >> n; int* a = new int [n];
    cout << "Pocetni   niz:";
    for (int i=0;i<n;i++) { cin>>a[i]; cout<<' '<<a[i]; } cout<<endl;
    Uredi<int>::uredi (a, n);
    cout << "Rastuci   niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    Uredi<int,Opada<int> >::uredi (a, n);
    cout << "Opadajuci niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    delete [] a;
  }

  { cout << "\nUredjivanje niza tacaka:\n\n";
    int n; cin >> n; Tacka* a = new Tacka [n];
    cout << "Pocetni   niz:";
    for (int i=0;i<n;i++) { cin>>a[i]; cout<<' '<<a[i]; } cout<<endl;
    Uredi<Tacka>::uredi (a, n);
    cout << "Rastuci   niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    Uredi<Tacka,Opada<Tacka> >::uredi (a, n);
    cout << "Opadajuci niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    delete [] a;
  }

  { cout << "\nUredjivanje niza pravougaonika:\n\n";
    int n; cin >> n; Pravoug* a = new Pravoug [n];
    cout << "Pocetni   niz:";
    for (int i=0;i<n;i++) { cin>>a[i]; cout<<' '<<a[i]; } cout<<endl;
    Uredi<Pravoug>::uredi (a, n);
    cout << "Rastuci   niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    Uredi<Pravoug,Opada<Pravoug> >::uredi (a, n);
    cout << "Opadajuci niz:";
    for (int i=0; i<n; i++) cout << ' ' << a[i]; cout << endl;
    delete [] a;
  }
}

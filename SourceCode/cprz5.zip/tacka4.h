// Definicja klase tacaka (Tacka).

#ifndef _tacka4_h_
#define _tacka4_h_

#include <iostream>
#include <cmath>
using namespace std;

namespace Figure {
  class Tacka {
    double x, y;                            // Koordinate.
  public:
    Tacka () { x = y = 0; }                 // Konstruktori.
    Tacka (double xx, double yy) { x = xx; y = yy; }
    double uzmi_x () const { return x; }    // Dohvatanje koordinata.
    double uzmi_y () const { return y; }
    double operator- (const Tacka& T) const // Rastojanje do druge tacke.
      { return sqrt (pow(x-T.x,2) + pow(y-T.y,2)); }
    friend istream& operator>> (istream& ut, Tacka& T)       // Citanje.
      { return ut >> T.x >> T.y; }
    friend ostream& operator<< (ostream& it, const Tacka& T) // Pisanje.
      { return it << '(' << T.x << ',' << T.y << ')'; }
  } ; // class Tacka
} // namespace Figure

#endif

// Program za ispitivanje klase Stek.

#include "stek1.h"
#include <iostream>
using namespace std;

int main () {
  while (true) {
    int n;
    cout << "\nDuzina niza brojeva? "; cin >> n;
  if (! n) break;
    cout << "Niz od " << n << " brojeva? ";
    for (int i=0, k; i<n; i++) { cin >> k; Stek::stavi (k); }
    cout << "Niz po obrnutom redosledu:";
    while (! Stek::prazan ()) cout << ' ' << Stek::uzmi (); cout << endl;
    Stek::prazni ();
  }
}

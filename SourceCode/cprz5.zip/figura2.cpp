// Definicija zajednickog polja uz klasu Figura.

#include "figura2.h"

int Figure::Figura::uk_id = 0;

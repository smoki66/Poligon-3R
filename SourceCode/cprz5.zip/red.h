// Definicija klase redova (Red).

class Red {
  struct Elem {                          // Elementi reda:
    int   pod;                           //   sadrzaj elementa,
    Elem* sled;                          //   sledeci element;
    Elem (int p, Elem* s=0)              //   konstruktor.
      { pod = p; sled = s; }
  } ;
  Elem *prvi, *posl;                     // Pocetak i kraj reda.
  int   duz;                             // Duzina reda.
  void  kopiraj (const Red& r);          // Kopiranje reda.
  void  brisi ();                        // Brisanje svih elemenata.
public:
  Red () { prvi = posl = 0; duz = 0; }   // Konstruktor praznog reda.
  Red (int a)                            // Konverzija int u Red.
    { prvi = posl = new Elem (a); duz = 1; }
  Red (const Red& r) { kopiraj (r); }    // Konstruktor kopije.
  ~Red () { brisi (); }                  // Destruktor.
  Red& operator=  (const Red& r) {       // Dodela vrednosti.
    if (this != &r) { brisi (); kopiraj (r); }
    return *this;
  }
  int operator+ () const { return duz; } // Duzina reda.
  Red& operator+= (const Red& r) ;       // Dodavanje reda.
  Red operator+ (const Red& r) const ;   // Spoj dva reda.
  int operator-- () ;                    // Brisanje prvog elementa.
  int operator-  () const                // Prvi element.
    { return duz ? prvi->pod : 0; }
  Red operator-  (int k) const ;         // Red bez elemenata jednakih k.
  Red& operator-= (int k)          // Brisanje svih elemenata jednakih k.
    { return *this = *this - k; }
  Red& operator~  ()               // Brisanje svih elemenata.
    { brisi (); return *this; }
} ;
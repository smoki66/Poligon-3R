// Definicija klase za stek celih brojeva (Stek).

class Stek {
  static Stek* vrh;           // Zajednicki pokazivac na vrh steka.
  Stek*  preth;               // Pokazivac na prethodni objekat na steku.
  int    broj;                // Koristan sadrzaj objekta na steku.
public:
  static void stavi (int i) ; // Stavljanje novog podatka na stek.
  static int  uzmi () ;       // Uzimanje podatka sa steka.
  static bool prazan () { return vrh == 0; }  // Da li je stek prazan?
  static void prazni () ;     // Praznjenje steka.
} ;

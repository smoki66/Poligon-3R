// Ispitivanje klasa za zbirke figura.

#include "krug2.h"
#include "kvadrat.h"
#include "trougao1.h"
#include "niz2.h"
#include "lista.h"
#include "iter.h"
#include "liter.h"
#include <iostream>
using namespace std;

Figura* citaj () {                      // CITANJE FIGURE.
  cout << "Vrsta (o, k, t)? "; char vrsta; cin >> vrsta;
  Figura* pf = 0;
  switch (vrsta) {
    case 'o': case 'O':
      pf = new Krug;    cout << "x, y, r? ";       break;
    case 'k': case 'K':
      pf = new Kvadrat; cout << "x, y, a? ";       break;
    case 't': case 'T':
      pf = new Trougao; cout << "x, y, a, b, c? "; break;
  }
  if (pf) cin >> *pf;
  return pf;
}

Zbirka* stvori () {                     // STVARANJE ZBIRKE.
  cout << "Vrsta (n,l)? "; char vrsta; cin >> vrsta;
  switch (vrsta) {
    case 'n': case 'N': return new Niz;
    case 'l': case 'L': return new Lista;
    default:            return 0;
  }
}

int main () {                           // GLAVNA FUNKCIJA.
  Zbirka* pz = new Niz;                 // Pokazivac na zbirku.
  Iter*   pi = pz->iter ();             // Pokazivac na iterator.
//  *pz += new Krug (3, Tacka(1,2));
//  *pz += new Trougao (3, 4, 5, Tacka(7,8));
//  *pz += new Kvadrat (2, Tacka(9,8));
  for (bool dalje=true; dalje; ) {

    // Ispisivanje menija.
    cout << "\nMoguce operacije su:\n\n"
            "1 Citaj figuru i stavi         7 Pocni iteracije\n"
            "2 Dohvati figuru i stavi       8 Idi na sledecu i prikazi\n"
            "3 Dohvati figuru i prikazi     9 Prikazi tekucu figuru\n"
            "4 Promeni vrstu zbirke         0 Brisi tekucu figuru\n"
            "5 Prikazi zbirku\n"
            "6 Isprazni zbirku              k Zavrsi s radom\n"
            "\nUnesite svoj izbor: ";
    char izb; cin >> izb;
    switch (izb) {

      // Citanje figure i stavljanje na kraj zbirke.
      case '1': if (Figura* pf = citaj ()) *pz += pf;
                  else cout << "*** Neispravna vrsta!\n\a";
                break;

      // Kopiranje odabrane figure na kraj zbirke.
      case '2': { int ind; cout << "Redni broj figure? "; cin >> ind;
                  if (ind >= 0 && ind < +*pz) *pz += *(*pz)[ind];
                    else cout << "*** Neispravan indeks!\n\a";
                  break;
                }

      // Prikazivanje odabrane figure.
      case '3': { int ind; cout << "Redni broj figure? "; cin >> ind;
                  if (ind >= 0 && ind < +*pz)
                          cout << "  " << *(*pz)[ind] << endl;
                    else  cout << "*** Neispravan indeks!\n\a";
                  break;
                }

      // Promena vrste zbirke.
      case '4': { Zbirka* ppz = stvori ();
                  if (!ppz) { cout<<"*** Neispravna vrsta!\n\a"; break; }
                  for (pi->poc(); pi->ima(); *ppz += ~*pi);
                  delete pz; pz = ppz;
                  delete pi; pi = pz->iter ();
                }

      // Prikazivanje sadrzaja zbirke.
      case '5': cout << *pz; break;

      // Praznjenje zbirke.
      case '6': ~*pz;pi->poc(); break;

      // Pocetak novih iteracija.
      case '7': pi->poc(); break;

      // Prelazak na sledeci element zbirke.
      case '8': ++*pi;

      // Prikazivanje tekuceg elementa zbirke.
      case '9': if (pi->ima()) cout << "  " << **pi << endl;
                  else cout << "*** Nema tekuce figure!\n\a";
                break;

      // Brisanje tekuce figure iz zbirke.
      case '0': if (pi->ima()) delete ~*pi;
                  else cout << "*** Nema tekuce figure!\n\a";
                break;

      // Zavrsetak rada.
      case 'k': case 'K': dalje = false; break;

      // Poruka o neispravnom izboru.
      default : cout << "*** Neispravan izbor!\n\a";
    }
  }
}

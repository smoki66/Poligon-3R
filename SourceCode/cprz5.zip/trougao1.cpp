// Definicije metoda uz klasu Trougao.

#include "trougao1.h"
#include <cmath>
using namespace std;

Real Trougao::P () const {                 // Povrsina.
  Real s = (a + b + c) / 2;
  return sqrt (s * (s-a) * (s-b) * (s-c));
}

void Trougao::citaj (istream& ut)          // Citanje.
  { Figura::citaj (ut); ut >> a >> b >> c; }

void Trougao::pisi  (ostream& it) const {  // Pisanje.
  it << "trougao [";
  Figura::pisi (it);
  it << ", a=" << a << ", b=" << b   << ", c=" << c
     << ", O=" << O() << ", P=" << P() << ']';
}

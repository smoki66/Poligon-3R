// Definicija apstraktne klase za iteratore (Iter).

#ifndef _iter_h_
#define _iter_h_

class Figura; // Deklaracija klase Figura.

class Iter {
public:
  virtual ~Iter () {}                           // Virtuelni destruktor.
  virtual bool ima () const =0;                 // Ima li tekuceg elementa?
  virtual Iter &poc () =0;                      // Pomeranje na pocetak.
  virtual Iter& operator++ () =0;               // Pomeranje korak napred.
  virtual Figura* operator-> () =0;             // Pokazivac na figuru.
  friend  Figura& operator* (Iter& i)           // Vrednost figure.
    { return *i.operator->(); }
  virtual Iter& operator+= (Figura* fig) =0;    // Umetanje figure.
  virtual Iter& operator-= (Figura*& fig) =0;   // Vadjenje figure.
  Figura* operator~ ()                          // Vadjenje figure.
    { Figura *fig; *this -= fig; return fig; }

  // Varijante ranijih operacija za nepromenljive zbirke.
  virtual const Iter& poc () const =0;          // Pomeranje na pocetak.
  virtual const Iter& operator++ () const =0;   // Pomeranje korak napred.
  virtual const Figura* operator->() const =0;  // Pokazivac na figuru.
  friend const Figura& operator* (const Iter &i)// Vrednost figure.
    { return *i.operator->(); }
} ;

#endif

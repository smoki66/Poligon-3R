// Program za ispitivanje klase Red.

#include "red.h"
#include <iostream>
using namespace std;

Red citaj (const char* nasl) {
  Red r; int n, a, i; cin >> n;
  cout << nasl << " :";
  for (i=0; i<n; i++) {cin >> a; cout << ' ' << a; r += a;} cout << endl;
  return r;
}

void pisi (const char* nasl, const Red& red) {
  Red r = red;
  cout << nasl << " :"; while (+r) cout << ' ' << --r; cout << endl;
}

int main () {
  Red r1 = citaj ("niz1  ");
            pisi ("r1    ", r1   );
  Red r2 = citaj ("niz2  ");
            pisi ("r2    ", r2   );
            pisi ("r1+r2 ", r1+r2);
  r1 += r2; pisi ("r1+=r2", r1   );
            pisi ("-r1   ", -r1  );
  --r1;     pisi ("--r1  ", r1   );
  int a;  cin  >> a;
          cout << "a      : " << a << endl;
            pisi ("r1-a  ", r1-a );
  r1 -= a;  pisi ("r1-=a ", r1   );
  ~r1;      pisi ("~r1   ", r1   );
}
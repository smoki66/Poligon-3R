// Definicije metoda uz klasu Crtez.

#include "crtez.h"
#include <string>
using namespace std;

void Figure::Crtez::kopiraj (const Crtez& crt) {  // Kopiranje crteza.
  A = crt.A; s = crt.s; v = crt.v;
  for (vector<Figura*>::const_iterator i=figure.begin();
       i!=figure.end(); figure.push_back((*i++)->kopija()));
}

void Figure::Crtez::brisi () {                    // Unistavanje crteza.
  for (vector<Figura*>::const_iterator i=figure.begin();
       i!=figure.end(); delete *i++);
  figure.clear ();
}

Figure::Boja Figure::Crtez::boja (const Tacka& T) const { // Boja tacke.
  if (! pripada (T)) throw G_tacka_ne_pripada ();
  Tacka T1 (T.uzmi_x()-A.uzmi_x(), T.uzmi_y()-A.uzmi_y());
  for (vector<Figura*>::const_reverse_iterator i=figure.rbegin();
       i!=figure.rend(); i++)
    try { return (*i)->boja (T1); } catch (G_tacka_ne_pripada) {}
  return Figura::boja ();
}

void Figure::Crtez::pisi (ostream& it) const {    // Pisanje.
  static string marg = "";
  it << " A=" << A << " s=" << s << " v=" << v;
  marg += "   ";
  for (vector<Figura*>::const_iterator i=figure.begin();
       i!=figure.end(); it << endl << marg << **i++);
  marg.erase(0,3);
}

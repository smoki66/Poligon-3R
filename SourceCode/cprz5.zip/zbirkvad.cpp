#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

class Pravi {       // Generisanje uzastopnih celih brojeva.
  int br, kor;
public:
  Pravi (int p=1, int d=1): br(p-d), kor(d) {}
  int operator() () { return br += kor; }
} ;

struct Kvadrat {    // Izracunavanje kvadrata celog broja.
  int operator() (const int& k) { return k * k; }
} ;

struct Pisi {       // Ispisivanje celog broja.
  void operator() (const int& k) { cout << k << ' '; }
} ;

class Zbir {       // Kumulativno sabiranje celih brojeva.
  int rez;
public:
  Zbir (): rez() {}
  void operator() (const int& k) { rez += k; }
  int operator+ () const { return rez; }
} ;

int main () {
  cout << "Broj sabiraka? "; int n; cin >> n;
  cout << "Pocetni broj?  "; int p; cin >> p;
  cout << "Korak?         "; int d; cin >> d;
  vector<int> v (n);
  vector<int>::iterator prvi=v.begin(), posl=v.end();
  generate  (prvi, posl, Pravi(p,d));
  cout << "Brojevi=       "; for_each (prvi, posl, Pisi()); cout << endl;
  transform (prvi, posl, prvi, Kvadrat());
  cout << "Kvadrati=      "; for_each (prvi, posl, Pisi()); cout << endl;
  cout << "Zbir kvadrata= "
       << + for_each (prvi, posl, Zbir()) << endl;
}
